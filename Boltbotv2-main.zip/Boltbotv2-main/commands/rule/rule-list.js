const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'rulelist',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const bolt = client.guilds.cache.get('842019142118014996')
        const ruleembed = new MessageEmbed()
        .setTitle(`${bolt.name} Rules List`)
        .setDescription(`Use ${prefix}rule <number of rule> for more information about that rule (Not done)`)
        .addField('Rules: ', '**1. Be respectful**\n**2. No NSFW or inappropriate language**\n**3. No spamming or flooding**\n**4. No advertisements**\n**5. Respect the staff**\n**6. No begging**\n**7. Server Raiding**\n**8. Have common sense**\n**9. English only**\n**10. Do not talk about sensitive topics**\n**11. Do not make excuses**\n**12. 11. Follow the Discord Community Guidelines**', false)

        message.channel.send(ruleembed)
    }
}