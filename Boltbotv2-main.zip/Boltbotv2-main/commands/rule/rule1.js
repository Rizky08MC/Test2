const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'rule1',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const embed = new MessageEmbed()
        .setDescription('**1. Be respectful** \nYou must respect everyone, regardless of your liking towards them. Treat others the way you want to be treated.')

        message.channel.send(embed)
    }
}