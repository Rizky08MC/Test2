const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'claimedcl',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission('ADMINISTRATOR'))) return;
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!args[0]) return message.reply('Who claiming <:BRUH:845447439254945802>')
        const claimedrole = message.guild.roles.cache.get('845453370520633355')

        const claimlogs = client.channels.cache.get('845453444172349480')

        claimlogs.send(`${target} **Claimed \`Nitro Classic\` From a Giveaway** <a:b_tada:845457418561126461>`).then(msg => msg.react('<:LEGIT:845541409988542464>')).then(target.roles.add(claimedrole)).then(message.delete())
    }
}
