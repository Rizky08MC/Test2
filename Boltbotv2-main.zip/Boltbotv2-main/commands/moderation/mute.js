const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'mute',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const noperm = new MessageEmbed()
        .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have 1 of this roles \`୧・Moderator, ୧・Head Moderator, ୧・Administrator\` or \`ADMINISTRATOR\` permission')
        .setColor('ff0000')

        if(message.member.roles.cache.find(blacklist => blacklist.id === '851396115790037062')) return message.reply('This user is blacklisted from using my command')
        if(!message.member.roles.cache.some(role => role.name === '୧・Moderator' || message.member.roles.cache.some(r => r.name ==='୧・Head Moderator' || message.member.roles.cache.some(ro => ro.name === '୧・Administrator' || message.member.hasPermission("ADMINISTRATOR"))))) return message.channel.send(noperm)

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        const reason = args.slice(1).join(' ') || 'No reason given';
        const muterole = message.guild.roles.cache.get('845453376942899231')

        const notarget = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:850213351954841610>**')
        .addField('Usage', `${prefix}mute <member> [reason]`)
        .addField('Example', `${prefix}mute @Cody example \n${prefix}mute 841748713885532180 example`)
        .setColor('ff0000')

        if(!member) return message.channel.send(notarget)

        const roleperm = new MessageEmbed()
        .setDescription('**Error! <:r_no:850213351954841610>** \nYou cant do that')
        .setColor('ff0000')

        if(message.member.roles.highest.position <= member.roles.highest.position) return message.channel.send(roleperm)

        const alreadyembed = new MessageEmbed()
        .setDescription('**This user is already muted**')
        .setColor('ff0000')

        if(member.roles.cache.find(role => role.id == `845453376942899231`)) return message.channel.send(alreadyembed)
        await member.roles.add(muterole)
        
        const succes = new MessageEmbed()
        .setDescription(`**Muted ${member.user.tag}** | ${reason}`)
        .setColor('59f50e')
        
        message.channel.send(succes)
    }
}
