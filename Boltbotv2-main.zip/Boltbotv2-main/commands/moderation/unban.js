const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'unban',
    description: 'Unban a member',
    run: async(client, message, args) => {
        const noperm = new MessageEmbed()
        .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have \`୧・Administrator\` role or \`BAN_MEMBERS\` permission')
        .setColor('ff0000')

        if(message.member.roles.cache.find(blacklist => blacklist.id === '851396115790037062')) return message.reply('This user is blacklisted from using my command')
        if(!message.member.roles.cache.some(role => role.name === '୧・Administrator' || message.member.hasPermission("BAN_MEMBERS"))) return message.channel.send(noperm)

        const argserr = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:847697016519655424>**')
        .addField('Usage', `${prefix}unban <userID>`)
        .addField('Example', `${prefix}unban 841748713885532180`)
        .setColor('ff0000')

        if(!args[0]) return message.channel.send(argserr)
        try {
            const user = await message.guild.members.unban(args[0]);
            const unbanembed = new MessageEmbed()
            .setDescription(`**${user.tag}** was unbanned`)
            .setColor('59f50e')
            .setTimestamp();

            return message.channel.send(unbanembed)
        } catch {
            const bannedx = new MessageEmbed()
            .setDescription('**Error! <:r_no:847697016519655424>** \nThis user is not banned')
            .setColor('FF0000')
            return message.channel.send(bannedx)
        }
    }
}
