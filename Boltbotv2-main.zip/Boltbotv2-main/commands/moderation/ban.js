const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'ban',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const noperm = new MessageEmbed()
        .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have \`୧・Administrator\` role or \`BAN_MEMBERS\` permission')
        .setColor('ff0000')

        if(message.member.roles.cache.find(blacklist => blacklist.id === '851396115790037062')) return message.reply('This user is blacklisted from using my command')
        if(!message.member.roles.cache.some(role => role.name === '୧・Administrator' || message.member.hasPermission("BAN_MEMBERS"))) return message.channel.send(noperm)
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const reason = args.slice(1).join(' ') || "No reason given"

        const notarget = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:850213351954841610>**')
        .addField('Usage', `${prefix}ban <member> [reason]`)
        .addField('Example', `${prefix}ban @Cody example \n${prefix}ban 841748713885532180 example`)
        .setColor('ff0000')

        if(!args[0]) return message.channel.send(notarget)

        const rolerr = new MessageEmbed()
        .setDescription('**Error! <:r_no:850213351954841610>** \nThis user role is higher')
        .setColor('ff0000')

        if(message.member.roles.highest.position <= member.roles.highest.position) return message.channel.send(rolerr)

        try {
            await member.ban({ reason })
            const kickembed = new MessageEmbed()
            .setDescription(`**Banned \`${member.user.tag}\`** | ${reason}`)
            .setColor('59f50e')
            .setTimestamp();
            message.channel.send(kickembed)
        } catch (err) {
            console.log(err)
            const errembed1 = new MessageEmbed()
            .setDescription('**Error! <:r_no:850213351954841610>** \nI cant ban this user')
            .setColor('ff0000')
            return message.channel.send(errembed1)
        }
    }
}
