const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'info',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        let totalSeconds = (client.uptime / 1000);
let days = Math.floor(totalSeconds / 86400);
totalSeconds %= 86400;
let hours = Math.floor(totalSeconds / 3600);
totalSeconds %= 3600;
let minutes = Math.floor(totalSeconds / 60);
let seconds = Math.floor(totalSeconds % 60);

        const owner = client.users.cache.get('581025443604594701')

        const infoembed = new MessageEmbed()
        .setTitle('Bot Info')
        .setDescription(`**Bot name:** ${client.user.tag} \n**Owner:** [${owner.tag}](https://discord.com/users/581025443604594701) \n**Uptime:** ${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`)
        .setColor('edcd55')

        message.channel.send(infoembed)

    }
}