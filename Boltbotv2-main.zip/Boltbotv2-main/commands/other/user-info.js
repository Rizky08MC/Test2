const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "userinfo",
    aliases : ['whois'],
    run: async (client, message, args) => {
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

        let status;
        switch (user.presence.status) {
            case "online":
                status = "<:r_online:848846058666721300> online";
                break;
            case "dnd":
                status = "<:r_dnd:848846218469834773> dnd";
                break;
            case "idle":
                status = "<:r_idle:848846388804321300> idle";
                break;
            case "offline":
                status = "<:r_offline:848846131180994570>offline";
                break;
        }

        let rolemap = message.guild.roles.cache .sort((a, b) => b.position - a.position) .map(r => r) .join(","); if (rolemap.length > 1024) rolemap = "To many roles to display"; if (!rolemap) rolemap = "No roles";

        const embed = new MessageEmbed()
            .setTitle(`${user.user.username} info`)
            .setColor(`00fbff`)
            .setThumbnail(user.user.displayAvatarURL({dynamic : true}))
            .addFields(
                {
                    name: "Name: ",
                    value: user.user.username,
                    inline: true
                },
                {
                    name: "Discriminator: ",
                    value: `#${user.user.discriminator}`,
                    inline: true
                },
                {
                    name: "ID: ",
                    value: user.user.id,
                },
                {
                    name: "Current Status: ",
                    value: status,
                    inline: true
                },
                {
                    name: "Activity: ",
                    value: user.presence.activities[0] ? user.presence.activities[0].name : `User isn't playing a game!`,
                    inline: true
                },
                {
                    name: 'Creation Date: ',
                    value: user.user.createdAt.toLocaleDateString("en-us"),
                    inline: false
                },
                {
                    name: 'Joined Date: ',
                    value: user.joinedAt.toLocaleDateString("en-us"),
                    inline: true
                },
                {
                    name: 'User Roles: ',
                    value: rolemap,
                    inline: false
                }
            )

        await message.channel.send(embed)
    }
}
