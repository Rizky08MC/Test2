const { MessageEmbed } = require('discord.js');
const { afk } = require('../../Collection');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'afk',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const reason = args.join(' ') || 'AFK';

        afk.set(message.author.id, [ Date.now(), reason ]);
        message.member.setNickname(`[AFK] ${message.author.username}`)
        message.channel.send(`${message.member} You're now afk: ${reason}`);
    }
}