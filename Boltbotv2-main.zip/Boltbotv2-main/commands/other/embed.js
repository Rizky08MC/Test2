const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'embed',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if(!message.member.hasPermission("MANAGE_MESSAGES")) return;

        const nocolorortarget = new MessageEmbed()
        .setDescription(`**Missing argument <:r_no:850213351954841610>**`)
        .addField('Usage', `${prefix}embed <color> <message>`, false)
        .addField('Example', `${prefix}embed #ffffff embed \n${prefix}embed none embed`, false)
        .setColor('ff0000')

        const color = args[0] || 'none' === '#ffffff'
        const embedmessage = args.slice(1).join(' ')

        if(!color) return message.channel.send(nocolorortarget)
        if(!embedmessage) return message.channel.send(nocolorortarget)

        const embed1 = new MessageEmbed()
        .setDescription(embedmessage)
        .setColor(color)

        message.channel.send(embed1).then(message.delete())
    }
}