const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "serverinfo",
    run: async (client, message, args) => {
        let region;
        switch (message.guild.region) {
            case "europe":
                region = '🇪🇺 Europe';
                break;
            case "us-east":
                region = '🇺🇸 us-east'
                break;
            case "us-west":
                region = '🇺🇸 us-west';
                break;
            case "us-south":
                region = '🇺🇸 us-south'
                break;
            case "us-central":
                region = '🇺🇸 us-central'
                break;
        }

        const embed = new MessageEmbed()
            .setThumbnail(message.guild.iconURL({dynamic : true}))
            .setColor('00fbff')
            .setTitle(`Server Info`)
            .addFields(
                {
                    name: "Owner: ",
                    value: message.guild.owner.user.tag,
                    inline: true
                },
                {
                    name: "Members: ",
                    value: `${message.guild.memberCount} Members`,
                    inline: true
                },
                {
                    name: "Members Online: ",
                    value: `${message.guild.members.cache.filter(m => m.user.presence.status == "online").size} Members online`,
                    inline: true
                },
                {
                    name: "Total Bots: ",
                    value: `${message.guild.members.cache.filter(m => m.user.bot).size} Bots`,
                    inline: true
                },
                {
                    name: "Creation Date: ",
                    value: message.guild.createdAt.toLocaleDateString("en-us"),
                    inline: true
                },
                {
                    name: "Roles Count: ",
                    value: `${message.guild.roles.cache.size} Roles`,
                    inline: true,
                },
                {
                    name: `Region: `,
                    value: region,
                    inline: true
                },
                {
                    name: `Verified: `,
                    value: message.guild.verified ? '<:r_yes:847695813861310514> Server is verified' : `<:r_no:847697016519655424> Server isn't verified`,
                    inline: true
                },
                {
                    name: 'Boosters: ',
                    value: message.guild.premiumSubscriptionCount >= 1 ? `${message.guild.premiumSubscriptionCount} Boosters` : `${message.guild.premiumSubscriptionCount} Boosters`,
                    inline: true
                },
                {
                    name: "Emojis: ",
                    value: message.guild.emojis.cache.size >= 1 ? `${message.guild.emojis.cache.size} Emojis` : `${message.guild.emojis.cache.size} Emojis` ,
                    inline: true
                }
            )
        await message.channel.send(embed)
    }
}