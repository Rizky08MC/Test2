const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'membercount',
    aliases : ['mc'],
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const mcembed = new MessageEmbed()
        .setTitle('Member Count')
        .setDescription(`**Total member:** ${message.guild.memberCount} \n**Member Online:** ${message.guild.members.cache.filter(m => m.user.presence.status == "online").size} \n**Bots:** ${message.guild.members.cache.filter(m => m.user.bot).size}`)
        .setColor('edcd55')

        message.channel.send(mcembed)
    }
}