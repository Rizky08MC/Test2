const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
  name: 'vote',
  run: async(client, message, args) => {
    const voteembed = new MessageEmbed()
    .setDescription('**You can vote with this link** \nhttps://top.gg/servers/361577445704466432')
    .setColor('00fbff')
    
    message.channel.send(voteembed)
  }
}
