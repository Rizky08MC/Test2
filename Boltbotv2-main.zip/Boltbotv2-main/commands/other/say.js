const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'say',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if(!message.member.hasPermission("MANAGE_MESSAGES")) return;

        const target = message.mentions.channels.first()
        const saymessage = args.slice(1).join(' ')

        const notarget = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:850213351954841610>**')
        .addField('Usage', `${prefix}say <channel> <message>`, false)
        .addField('Example', `${prefix}say #・💬୧。lounge example`)
        .setColor('ff0000')

        if(!target) return message.channel.send(notarget)
        if(!saymessage) return message.channel.send(notarget)

        target.send(saymessage).then(message.delete())
    }
}
