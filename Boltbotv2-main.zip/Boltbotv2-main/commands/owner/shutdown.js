const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'shutdown',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if (message.author.id !== '581025443604594701') return;

        const embed1 = new MessageEmbed()
        .setDescription('**Shutdown...**')
        .setColor('59f50e')

        await message.channel.send(embed1)
        process.exit()
    }
}