const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'blacklist',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if(message.author.id !== '581025443604594701') return;
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const blacklistrole = message.guild.roles.cache.get('851396115790037062')

        if(member.roles.cache.find(role => role.id == `851396115790037062`)) return message.channel.send('This user is already blacklisted')
        await member.roles.add(blacklistrole)
        message.channel.send(`${member.user.tag} is now blacklisted from using my command`)
    }
}
