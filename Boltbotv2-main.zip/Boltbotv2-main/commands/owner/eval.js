const { MessageEmbed } = require('discord.js');
const { inspect } = require('util')

module.exports = {
    name: 'eval',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        if(message.author.id !== '581025443604594701') return;

        const code = args.join(' ')
        if(!code) return;

        try {
            const result = await eval(code);
            let output = result;
            if(typeof result !== 'string') {
                output = inspect(result)
            }

            message.channel.send(output, { code: 'js'})
        } catch (err) {
            console.log(err)
            message.channel.send('Error')
        }
    }
}