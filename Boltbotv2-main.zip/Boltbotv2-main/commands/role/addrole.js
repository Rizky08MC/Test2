const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'addrole',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const noperm = new MessageEmbed()
        .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have \`୧・Moderator\` role or \`MANAGE_ROLES\` permission')
        .setColor('ff0000')
        
        if(message.member.roles.cache.find(blacklist => blacklist.id === '851396115790037062')) return message.reply('This user is blacklisted from using my command')
        if(!message.member.roles.cache.some(role => role.name === '୧・Moderator' || message.member.roles.cache.some(rol => rol.name === '୧・Head Moderator' || message.member.hasPermission("MANAGE_ROLES")))) return message.channel.send(noperm)
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        const role = message.guild.roles.cache.get(args[1])
        
        const notarget = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:850213351954841610>**')
        .addField('Usage', `${prefix}addrole <member> <role>`, false)
        .addField('Example', `${prefix}addrole @Cody 845453378972155944 \n${prefix}addrole 841748713885532180 845453378972155944`, false)
        .setColor('ff0000')

        if(!target) return message.channel.send(notarget)
        if(!role) return message.channel.send(notarget)

        const alreadyembed = new MessageEmbed()
        .setDescription('**This user already have that role**')
        .setColor('ff0000')

        if(target.roles.cache.find(role => role.id === args[1] )) return message.channel.send(alreadyembed)

        try {
            await target.roles.add(role)
            const succes = new MessageEmbed()
            .setDescription(`**Added \`${role.name}\` to ${target.user.tag}**`)
            .setColor('59f50e')
            message.channel.send(succes)
        } catch (err) {
            console.log(err)
            const errembed = new MessageEmbed()
            .setDescription('**Error! <:r_no:850213351954841610>**')
            .setColor('ff0000')
            return message.channel.send(errembed)
        }
    }
}
