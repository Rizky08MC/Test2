const { MessageEmbed } = require('discord.js');
const prefix = require('../../config.json').prefix;

module.exports = {
    name: 'setnick',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {
        const noperm = new MessageEmbed()
        .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have \`୧・Administrator\` role or \`ADMINISTRATOR\` permission')
        .setColor('ff0000')
  
          if(!message.member.roles.cache.some(role => role.name === '୧・Administrator' || message.member.hasPermission("ADMINISTRATOR"))) return message.channel.send(noperm)
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        const notarget = new MessageEmbed()
        .setDescription('**Missing argument <:r_no:850213351954841610>**')
        .addField('Usage', `${prefix}setnick <member> <new name>`, false)
        .addField('Example', `${prefix}setnick @cody example`)
        .setColor('ff0000')
        if(!target) return message.channel.send(notarget)
        if(!args[1]) return message.channel.send(notarget)

        try {
            await target.setNickname(args.slice(1).join(' '))
            const success = new MessageEmbed()
            .setDescription(`**Successfully changed nickname for** \`${target.user.tag}\` <:r_yes:850213334846144522>`)
            .setColor('59f50e')
            message.channel.send(success)
        } catch (err) {
            console.log(err)
            const errembed = new MessageEmbed()
            .setDescription('**Error! <:r_no:850213351954841610>**')
            .setColor('ff0000')
            return message.channel.send(errembed)
        }
    }
}