const { MessageEmbed } = require('discord.js')

module.exports = {
    name: 'nuke',
    description: 'Nuke a channel',
    run: async(client, message, args) => {
      const noperm = new MessageEmbed()
      .setDescription('**Missing permission <:r_no:850213351954841610>** \nYou need to have \`୧・Manager\` role or \`ADMINISTRATOR\` permission')
      .setColor('ff0000')

        if(!message.member.roles.cache.some(role => role.name === '୧・Manager' || message.member.hasPermission("ADMINISTRATOR"))) return message.channel.send(noperm)

        const mispermembed = new MessageEmbed()
        .setDescription('**Missing permission <:r_n:850213351954841610>**')
        .setColor('ff0000')
        if(!message.guild.me.hasPermission("MANAGE_CHANNELS")) return message.channel.send(mispermembed)
        
        const nukeembed = new MessageEmbed()
        .setTitle(`\`${message.author.tag}\` **nuked this channel**`)
        .setImage('https://cdn.discordapp.com/attachments/850191874495873066/850222964770209877/ezgif.com-video-to-gif.gif')
        .setColor('59f50e')
      
        if (!message.channel.parentID) {
          await message.channel.clone({ position: message.channel.rawPosition }).then((ch) => {
            ch.send(nukeembed)
          });
        } else {
          await message.channel.clone({ parent: message.channel.parentID, position: message.channel.rawPosition }).then((ch) => {
            ch.send(nukeembed)
          });
        }
        message.channel.delete();
      }
    }