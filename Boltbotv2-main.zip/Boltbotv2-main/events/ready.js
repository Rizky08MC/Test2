const client = require('../index');
const { prefix } = require('../config.json');

client.on('ready', () => {
    client.user.setActivity(`${prefix}help`, { type: 'WATCHING'})
    console.log(`${client.user.username} ✅`,)
})