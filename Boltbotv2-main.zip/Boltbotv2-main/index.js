const Discord = require('discord.js');
const fs = require('fs');
const { token, prefix } = require('./config.json');
const { MessageEmbed } = require('discord.js');
const ms = require('ms');
const client = new Discord.Client({
    disableEveryone: true
});

module.exports = client;
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
client.categories = fs.readdirSync("./commands/");
["command"].forEach(handler => {
    require(`./handlers/${handler}`)(client);
}); 

client.on('message', async message => {
    const regex = /^(<@!?835790054860259358>) prefix/i

if(message.content.match(regex)) {
    const prefixembed = new MessageEmbed()
    .setDescription(`**My prefix is \`${prefix}\`**`)
    .setColor('00FBFF')

    message.channel.send(message.author, prefixembed)
}
})

client.on('message', async message => {
    if(message.content.startsWith('?whois')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-messages')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))    
        }
    } else if(message.content.startsWith('-message')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-invite')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('b!whois')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('+invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-lb invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-top invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-lb messages')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('-top messages')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('+lb invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('+top invites')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo cash')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo give')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo balance')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo daily')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls beg')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls hunt')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls fish')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls daily')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls monthly')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls pm')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('pls rich')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo marry')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } else if(message.content.startsWith('owo divorce')) {
        const ids = ['845453441693646868', '845453442487156746']
        if(!message.member.roles.cache.some(role => role.name === '୧・Staff' || message.member.hasPermission("ADMINISTRATOR"))) {
        if(!ids.includes(message.channel.id)) return message.reply('Do that in <#845453441693646868>').then(msg => msg.delete({ timeout: 5000 })).then(message.delete({ timeout: 5000 }))
        }
    } 
});

client.on('message', async message => {
    if(message.content.toLowerCase() === 'its a bad word') {
    const target = message.member;
    const muterole = message.guild.roles.cache.get('845453376942899231')
    const time = 10000

    await target.roles.add(muterole)
    (await message.channel.send(`Muted ${message.member} for saying bad word`)).then(message.delete())
    setTimeout(async time => {
        await target.roles.remove(muterole)
        })
    }
})

client.login(token);
